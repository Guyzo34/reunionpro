import "./index.css";
import { useState, useEffect, useRef, useCallback } from "react";
import DailyIframe from "@daily-co/daily-js";
import {
  DailyProvider,
  useDaily,
  useLocalParticipant,
  useParticipantIds,
  useVideoTrack,
  useAudioTrack,
} from "@daily-co/daily-react";

const API = "/api"; // proxié vers localhost:4000

// ─────────────────────────────────────────────────────────────
// Utilitaires
// ─────────────────────────────────────────────────────────────
const randomColor = (s) => {
  const palette = ["#3d6fff","#00d4aa","#ff6b81","#a29bfe","#fd79a8","#fdcb6e","#6c5ce7","#00cec9"];
  let h = 0; for (const c of s) h += c.charCodeAt(0);
  return palette[h % palette.length];
};
const initials = (name = "") =>
  name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();

const fmt = (s) =>
  `${String(Math.floor(s / 60)).padStart(2,"0")}:${String(s % 60).padStart(2,"0")}`;

// ─────────────────────────────────────────────────────────────
// Styles inline (CSS-in-JS léger)
// ─────────────────────────────────────────────────────────────
const S = {
  // layout
  page: { minHeight:"100vh", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"2rem", position:"relative", overflow:"hidden" },
  grid: { position:"absolute", inset:0, backgroundImage:"linear-gradient(#252c4530 1px,transparent 1px),linear-gradient(90deg,#252c4530 1px,transparent 1px)", backgroundSize:"48px 48px", pointerEvents:"none" },
  glow: { position:"absolute", inset:0, background:"radial-gradient(ellipse 80% 50% at 50% 0%,#1a2a5e44,transparent 70%)", pointerEvents:"none" },

  // typography
  logo: { fontFamily:"var(--font-h)", fontWeight:800, fontSize:".9rem", letterSpacing:"3px", textTransform:"uppercase", color:"var(--accent)", marginBottom:"3rem" },
  heroTitle: { fontFamily:"var(--font-h)", fontSize:"clamp(2.4rem,6vw,4.2rem)", fontWeight:800, lineHeight:1.05, textAlign:"center", background:"linear-gradient(135deg,#fff 30%,#3d6fff)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text", maxWidth:640, marginBottom:"1rem" },
  heroSub: { fontSize:"1rem", color:"var(--muted)", textAlign:"center", marginBottom:"3rem", maxWidth:440, lineHeight:1.65 },

  // cards
  cardsRow: { display:"flex", gap:"1.25rem", flexWrap:"wrap", justifyContent:"center", maxWidth:680, width:"100%", zIndex:1 },
  card: (hov) => ({ background:hov?"#1c2238":"var(--card)", border:`1px solid ${hov?"var(--accent)":"var(--border)"}`, borderRadius:20, padding:"2rem", flex:1, minWidth:240, maxWidth:300, cursor:"pointer", transition:"all .2s", transform:hov?"translateY(-5px)":"none", boxShadow:hov?"0 16px 48px #3d6fff22":"none", position:"relative", overflow:"hidden" }),
  cardStrip: (c) => ({ position:"absolute", top:0, left:0, right:0, height:2, background:c }),
  cardIcon: { width:48, height:48, background:"#1e2740", borderRadius:12, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.4rem", marginBottom:"1rem" },
  cardH: { fontFamily:"var(--font-h)", fontSize:"1.15rem", fontWeight:700, marginBottom:".4rem" },
  cardP: { fontSize:".875rem", color:"var(--muted)", lineHeight:1.55 },

  // modal / overlay
  overlay: { position:"fixed", inset:0, background:"#000b", backdropFilter:"blur(8px)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200 },
  modal: { background:"var(--card)", border:"1px solid var(--border)", borderRadius:24, padding:"2.5rem", width:"min(460px,92vw)", animation:"fadeUp .25s ease both" },
  modalH: { fontFamily:"var(--font-h)", fontSize:"1.45rem", fontWeight:700, marginBottom:".4rem" },
  modalSub: { fontSize:".875rem", color:"var(--muted)", marginBottom:"2rem" },

  // form
  field: { marginBottom:"1.25rem" },
  label: { display:"block", fontSize:".78rem", fontWeight:500, color:"var(--muted)", marginBottom:".45rem", letterSpacing:".06em", textTransform:"uppercase" },
  input: (focus) => ({ width:"100%", background:"var(--surface)", border:`1px solid ${focus?"var(--accent)":"var(--border)"}`, borderRadius:12, padding:".85rem 1.1rem", color:"var(--text)", fontFamily:"var(--font-b)", fontSize:".95rem", outline:"none", transition:"border-color .2s" }),

  // buttons
  btnRow: { display:"flex", gap:".75rem", marginTop:"1.5rem" },
  btnPrimary: { display:"inline-flex", alignItems:"center", justifyContent:"center", gap:".5rem", padding:".85rem 1.5rem", borderRadius:12, border:"none", fontFamily:"var(--font-b)", fontSize:".95rem", fontWeight:500, cursor:"pointer", background:"linear-gradient(135deg,var(--accent),#5a85ff)", color:"#fff", flex:1, animation:"glow 2.5s ease infinite" },
  btnSecondary: { display:"inline-flex", alignItems:"center", justifyContent:"center", gap:".5rem", padding:".85rem 1.5rem", borderRadius:12, border:"1px solid var(--border)", fontFamily:"var(--font-b)", fontSize:".95rem", fontWeight:500, cursor:"pointer", background:"var(--surface)", color:"var(--text)", flex:1 },
  btnIcon: (active, variant) => ({
    width:48, height:48, borderRadius:14, border:"none", fontSize:"1.1rem", cursor:"pointer", transition:"all .15s",
    background: variant==="danger" ? "var(--danger)" : variant==="warn" ? "var(--warn)" : active ? "var(--accent)" : "var(--surface)",
    color: variant==="warn" ? "#000" : "#fff",
    display:"flex", alignItems:"center", justifyContent:"center",
    border: `1px solid ${variant==="danger" ? "var(--danger)" : variant==="warn" ? "var(--warn)" : active ? "var(--accent)" : "var(--border)"}`,
  }),

  // room
  room: { height:"100vh", display:"flex", flexDirection:"column", background:"var(--bg)" },
  header: { display:"flex", alignItems:"center", justifyContent:"space-between", padding:".9rem 1.5rem", background:"var(--surface)", borderBottom:"1px solid var(--border)", flexShrink:0 },
  controls: { display:"flex", alignItems:"center", justifyContent:"center", gap:".75rem", padding:"1rem 1.5rem", background:"var(--surface)", borderTop:"1px solid var(--border)", flexShrink:0, flexWrap:"wrap" },
  sep: { width:1, height:32, background:"var(--border)", margin:"0 .25rem" },
  videoGrid: (n) => ({ flex:1, display:"grid", gap:8, padding:"1rem", overflow:"hidden", gridTemplateColumns: n===1?"1fr":n===2?"1fr 1fr":"repeat(2,1fr)", gridTemplateRows: n<=2?"1fr":n<=4?"1fr 1fr":"repeat(3,1fr)" }),
  tile: (speaking) => ({ background:"var(--card)", borderRadius:16, position:"relative", overflow:"hidden", border:`2px solid ${speaking?"var(--accent2)":"transparent"}`, transition:"border-color .3s" }),
  tileAvatar: { position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:".5rem" },
  avatarCircle: (color) => ({ width:72, height:72, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"var(--font-h)", fontSize:"1.6rem", fontWeight:700, color:"#fff", background:color }),
  tileName: { position:"absolute", bottom:10, left:10, background:"#000b", borderRadius:8, padding:".3rem .6rem", fontSize:".78rem", fontWeight:500, display:"flex", alignItems:"center", gap:".4rem" },

  // share bar
  shareBar: { background:"var(--card)", border:"1px solid var(--border)", borderRadius:16, padding:"1.25rem 1.5rem", margin:"0 1rem .5rem", display:"flex", alignItems:"center", gap:".75rem", flexWrap:"wrap", animation:"fadeUp .3s ease both" },
  shareLink: { flex:1, background:"var(--surface)", border:"1px solid var(--border)", borderRadius:10, padding:".7rem 1rem", fontSize:".83rem", color:"var(--muted)", minWidth:200, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" },
  btnCopy: (c) => ({ background:c||"var(--accent)", border:"none", borderRadius:10, padding:".7rem 1.1rem", color:"#fff", fontFamily:"var(--font-b)", fontSize:".875rem", fontWeight:500, cursor:"pointer", whiteSpace:"nowrap", display:"flex", alignItems:"center", gap:".4rem" }),

  // recording dot
  recBadge: { display:"flex", alignItems:"center", gap:".45rem", background:"#ff475720", border:"1px solid var(--danger)", borderRadius:8, padding:".28rem .75rem", fontSize:".78rem", color:"var(--danger)", fontWeight:600 },
  dot: (c,pulse) => ({ width:7, height:7, borderRadius:"50%", background:c, animation:pulse?"pulse 1.4s infinite":"none" }),

  // summary
  summaryCard: { background:"var(--card)", border:"1px solid var(--border)", borderRadius:24, padding:"2.5rem", width:"min(640px,92vw)", animation:"fadeUp .4s ease both" },
  summaryH: { fontFamily:"var(--font-h)", fontSize:"1.5rem", fontWeight:700, marginBottom:".4rem" },
  meta: { fontSize:".85rem", color:"var(--muted)", marginBottom:"2rem" },
  transcriptBox: { background:"var(--surface)", border:"1px solid var(--border)", borderRadius:14, padding:"1.4rem", maxHeight:280, overflowY:"auto", marginBottom:"1.5rem", fontSize:".875rem", lineHeight:1.75, color:"#c5cce0" },
  summaryBox: { background:"#1a2740", border:"1px solid #2a3d60", borderRadius:14, padding:"1.4rem", marginBottom:"1.5rem", fontSize:".875rem", lineHeight:1.75, color:"#d0daf5" },
  loadBar: { height:4, background:"var(--surface)", borderRadius:4, overflow:"hidden", marginBottom:"1rem" },
  loadFill: (p) => ({ height:"100%", background:"linear-gradient(90deg,var(--accent),var(--accent2))", borderRadius:4, width:`${p}%`, transition:"width .5s ease" }),
  toast: { position:"fixed", bottom:"2rem", left:"50%", transform:"translateX(-50%)", background:"var(--accent)", color:"#fff", padding:".8rem 1.5rem", borderRadius:12, fontSize:".9rem", fontWeight:500, zIndex:999, animation:"fadeUp .3s ease both", boxShadow:"0 8px 24px #3d6fff44", whiteSpace:"nowrap" },
};

// ─────────────────────────────────────────────────────────────
// Composant Toast
// ─────────────────────────────────────────────────────────────
function Toast({ msg, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2800); return () => clearTimeout(t); }, []);
  return <div style={S.toast}>{msg}</div>;
}

// ─────────────────────────────────────────────────────────────
// Tuile vidéo — participant individuel
// ─────────────────────────────────────────────────────────────
function VideoTile({ id }) {
  const participant = useLocalParticipant();
  const videoRef   = useRef();
  const video      = useVideoTrack(id);
  const audio      = useAudioTrack(id);
  const daily      = useDaily();

  // Nom du participant depuis les métadonnées
  const info = daily?.participants()?.[id];
  const name = info?.user_name || "Participant";
  const color = randomColor(name);
  const speaking = info?.active_speaker || false;

  useEffect(() => {
    if (videoRef.current && video?.persistentTrack) {
      videoRef.current.srcObject = new MediaStream([video.persistentTrack]);
    }
  }, [video]);

  const camOff = video?.isOff;
  const micOff = audio?.isOff;

  return (
    <div style={S.tile(speaking)}>
      {!camOff ? (
        <video ref={videoRef} autoPlay muted={info?.local} playsInline
          style={{ width:"100%", height:"100%", objectFit:"cover", transform: info?.local ? "scaleX(-1)":"none", display:"block" }}
        />
      ) : (
        <div style={S.tileAvatar}>
          <div style={S.avatarCircle(color)}>{initials(name)}</div>
          <span style={{ fontSize:".8rem", color:"var(--muted)" }}>Caméra désactivée</span>
        </div>
      )}
      <div style={S.tileName}>
        {name} {info?.local && "(Moi)"}
        {micOff && <span style={{ color:"var(--danger)", fontSize:".75rem" }}>🔇</span>}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Salle de réunion Daily.co
// ─────────────────────────────────────────────────────────────
function RoomInner({ session, onLeave }) {
  const daily     = useDaily();
  const local     = useLocalParticipant();
  const ids       = useParticipantIds();

  const [micOn,     setMicOn]     = useState(true);
  const [camOn,     setCamOn]     = useState(true);
  const [recording, setRec]       = useState(false);
  const [elapsed,   setElapsed]   = useState(0);
  const [showShare, setShare]     = useState(false);
  const [toast,     setToast]     = useState(null);

  const meetingLink = `${window.location.origin}/join/${session.roomName}`;
  const waLink = `https://wa.me/?text=${encodeURIComponent(
    `🎬 Rejoignez notre réunion "${session.title || "Réunion"}"\n${meetingLink}\nCode : ${session.roomName.split("-").pop()}`
  )}`;

  useEffect(() => {
    const t = setInterval(() => setElapsed(e => e + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const toggleMic = useCallback(() => {
    daily?.setLocalAudio(!micOn);
    setMicOn(m => !m);
  }, [daily, micOn]);

  const toggleCam = useCallback(() => {
    daily?.setLocalVideo(!camOn);
    setCamOn(c => !c);
  }, [daily, camOn]);

  const toggleRecord = useCallback(async () => {
    if (!recording) {
      await daily?.startRecording();
      setRec(true); setToast("⏺️ Enregistrement démarré");
    } else {
      await daily?.stopRecording();
      setRec(false); setToast("⏹️ Enregistrement arrêté");
    }
  }, [daily, recording]);

  const shareScreen = useCallback(async () => {
    try { await daily?.startScreenShare(); }
    catch { setToast("Partage d'écran annulé"); }
  }, [daily]);

  const count = ids.length;

  return (
    <div style={S.room}>
      {/* Header */}
      <div style={S.header}>
        <div>
          <div style={{ fontFamily:"var(--font-h)", fontWeight:700, fontSize:"1rem" }}>
            {session.title || "Réunion"}
          </div>
          <div style={{ fontSize:".8rem", color:"var(--muted)" }}>
            Code : {session.roomName.split("-").pop()?.toUpperCase()} · {fmt(elapsed)}
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:".75rem" }}>
          {recording && (
            <div style={S.recBadge}>
              <div style={S.dot("var(--danger)", true)} />
              REC
            </div>
          )}
          <span style={{ fontSize:".85rem", color:"var(--muted)" }}>
            {count} participant{count > 1 ? "s" : ""}
          </span>
        </div>
      </div>

      {/* Share bar */}
      {showShare && (
        <div style={S.shareBar}>
          <span style={{ fontSize:"1.3rem" }}>🔗</span>
          <div style={S.shareLink}>{meetingLink}</div>
          <button style={S.btnCopy()} onClick={() => { navigator.clipboard?.writeText(meetingLink); setToast("✅ Lien copié !"); }}>
            Copier
          </button>
          <a href={waLink} target="_blank" rel="noreferrer">
            <button style={S.btnCopy("#25D366")}>📱 WhatsApp</button>
          </a>
        </div>
      )}

      {/* Video grid */}
      <div style={S.videoGrid(Math.min(count, 6))}>
        {ids.map(id => <VideoTile key={id} id={id} />)}
      </div>

      {/* Controls */}
      <div style={S.controls}>
        <button style={S.btnIcon(micOn)} title={micOn ? "Couper micro" : "Activer micro"} onClick={toggleMic}>
          {micOn ? "🎙️" : "🔇"}
        </button>
        <button style={S.btnIcon(camOn)} title={camOn ? "Éteindre caméra" : "Allumer caméra"} onClick={toggleCam}>
          {camOn ? "📹" : "🚫"}
        </button>
        <div style={S.sep} />
        <button style={S.btnIcon(false)} title="Partager l'écran" onClick={shareScreen}>🖥️</button>
        <button style={S.btnIcon(showShare)} title="Inviter" onClick={() => setShare(v => !v)}>🔗</button>
        <div style={S.sep} />
        <button style={S.btnIcon(recording, recording?"warn":"")} title="Enregistrer" onClick={toggleRecord}>
          {recording ? "⏹️" : "⏺️"}
        </button>
        <div style={S.sep} />
        <button style={S.btnIcon(false,"danger")} title="Quitter" onClick={onLeave}>📵</button>
      </div>

      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    </div>
  );
}

function Room({ session, onLeave }) {
  const callObject = useRef(null);

  useEffect(() => {
    callObject.current = DailyIframe.createCallObject();
    callObject.current.join({ url: session.roomUrl, token: session.token });
    return () => { callObject.current?.leave(); callObject.current?.destroy(); };
  }, []);

  if (!callObject.current) return null;

  return (
    <DailyProvider callObject={callObject.current}>
      <RoomInner session={session} onLeave={onLeave} />
    </DailyProvider>
  );
}

// ─────────────────────────────────────────────────────────────
// Salle d'attente
// ─────────────────────────────────────────────────────────────
function WaitingRoom({ session, onEnter }) {
  const vRef  = useRef();
  const [stream, setStream] = useState(null);
  const [micOn,  setMicOn]  = useState(true);
  const [camOn,  setCamOn]  = useState(true);
  const [err,    setErr]    = useState(null);

  useEffect(() => {
    navigator.mediaDevices?.getUserMedia({ video:true, audio:true })
      .then(s => { setStream(s); if (vRef.current) vRef.current.srcObject = s; })
      .catch(() => setErr("Accès caméra/micro refusé — continuez sans."));
    return () => stream?.getTracks().forEach(t => t.stop());
  }, []);

  return (
    <div style={{ ...S.page, gap:"1.5rem" }}>
      <div style={S.grid} />
      <div style={S.logo} className="fade-up">● ReunionPro</div>

      {/* Preview */}
      <div style={{ position:"relative", width:"min(380px,90vw)", aspectRatio:"4/3", background:"var(--card)", border:"1px solid var(--border)", borderRadius:20, overflow:"hidden" }} className="fade-up d1">
        {stream && camOn ? (
          <video ref={vRef} autoPlay muted playsInline style={{ width:"100%", height:"100%", objectFit:"cover", transform:"scaleX(-1)" }} />
        ) : (
          <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:".75rem", color:"var(--muted)", fontSize:".9rem" }}>
            <span style={{ fontSize:"2.5rem" }}>📷</span>
            {err || "Caméra désactivée"}
          </div>
        )}
        <div style={{ position:"absolute", top:10, right:10, background:"#000a", borderRadius:8, padding:".3rem .7rem", fontSize:".75rem", fontWeight:500, display:"flex", alignItems:"center", gap:".4rem" }}>
          <div style={S.dot("var(--accent2)", true)} /> Aperçu
        </div>
      </div>

      {/* Toggles */}
      <div style={{ display:"flex", gap:".75rem" }} className="fade-up d2">
        <button style={S.btnIcon(micOn)} onClick={() => setMicOn(v => !v)}>
          {micOn ? "🎙️" : "🔇"}
        </button>
        <button style={S.btnIcon(camOn)} onClick={() => setCamOn(v => !v)}>
          {camOn ? "📹" : "🚫"}
        </button>
      </div>

      <div style={{ textAlign:"center" }} className="fade-up d3">
        <h2 style={{ fontFamily:"var(--font-h)", marginBottom:".4rem" }}>
          {session.title || "Réunion en attente"}
        </h2>
        <p style={{ color:"var(--muted)", fontSize:".9rem", marginBottom:"1.5rem" }}>
          Bonjour, <strong style={{ color:"var(--text)" }}>{session.name}</strong> — tout est prêt ?
        </p>
        <button style={{ ...S.btnPrimary, minWidth:220 }} onClick={() => onEnter(stream, camOn, micOn)}>
          Rejoindre maintenant →
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Modals
// ─────────────────────────────────────────────────────────────
function FocusInput({ value, onChange, placeholder, style }) {
  const [focused, setFocused] = useState(false);
  return (
    <input
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      style={{ ...S.input(focused), ...style }}
    />
  );
}

function CreateModal({ onClose, onStart }) {
  const [name,  setName]  = useState("");
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleCreate = async () => {
    if (!name.trim()) return;
    setLoading(true); setError(null);
    try {
      const roomName = `reunionpro-${Math.random().toString(36).slice(2,8)}`;

      // 1. Créer la salle Daily.co
      const roomRes = await fetch(`${API}/rooms`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ roomName, title }),
      });
      const room = await roomRes.json();
      if (room.error) throw new Error(JSON.stringify(room.error));

      // 2. Obtenir un token hôte
      const tokRes = await fetch(`${API}/rooms/token`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ roomName, userName: name, isOwner: true }),
      });
      const tok = await tokRes.json();

      onStart({ name, title, roomName, roomUrl: room.url, token: tok.token, isOwner: true });
    } catch (e) {
      setError("Erreur : " + e.message + " — Vérifiez vos clés API dans .env");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={S.overlay} onClick={onClose}>
      <div style={S.modal} onClick={e => e.stopPropagation()}>
        <h2 style={S.modalH}>🎬 Nouvelle réunion</h2>
        <p style={S.modalSub}>Une salle sécurisée sera créée sur Daily.co</p>

        {error && <div style={{ background:"#ff475722", border:"1px solid var(--danger)", borderRadius:10, padding:".75rem 1rem", fontSize:".85rem", color:"var(--danger)", marginBottom:"1rem" }}>{error}</div>}

        <div style={S.field}>
          <label style={S.label}>Votre nom</label>
          <FocusInput value={name} onChange={e => setName(e.target.value)} placeholder="Ex : Kouassi Martin" />
        </div>
        <div style={S.field}>
          <label style={S.label}>Titre de la réunion</label>
          <FocusInput value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex : Point partenariat Q2" />
        </div>

        <div style={S.btnRow}>
          <button style={S.btnSecondary} onClick={onClose}>Annuler</button>
          <button style={{ ...S.btnPrimary, opacity: loading||!name.trim() ? .6:1 }} onClick={handleCreate} disabled={loading || !name.trim()}>
            {loading ? "Création…" : "Créer la salle →"}
          </button>
        </div>
      </div>
    </div>
  );
}

function JoinModal({ onClose, onStart }) {
  const [name,  setName]  = useState("");
  const [code,  setCode]  = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleJoin = async () => {
    if (!name.trim() || code.length < 4) return;
    setLoading(true); setError(null);
    try {
      const roomName = code.toLowerCase().startsWith("reunionpro-") ? code : `reunionpro-${code.toLowerCase()}`;
      const tokRes = await fetch(`${API}/rooms/token`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ roomName, userName: name, isOwner: false }),
      });
      const tok = await tokRes.json();
      if (tok.error) throw new Error(JSON.stringify(tok.error));

      const roomUrl = `https://${window.DAILY_DOMAIN || "yourapp"}.daily.co/${roomName}`;
      onStart({ name, roomName, roomUrl, token: tok.token, isOwner: false });
    } catch(e) {
      setError("Impossible de rejoindre : " + e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={S.overlay} onClick={onClose}>
      <div style={S.modal} onClick={e => e.stopPropagation()}>
        <h2 style={S.modalH}>🔗 Rejoindre une réunion</h2>
        <p style={S.modalSub}>Entrez le code reçu par WhatsApp</p>

        {error && <div style={{ background:"#ff475722", border:"1px solid var(--danger)", borderRadius:10, padding:".75rem 1rem", fontSize:".85rem", color:"var(--danger)", marginBottom:"1rem" }}>{error}</div>}

        <div style={S.field}>
          <label style={S.label}>Votre nom</label>
          <FocusInput value={name} onChange={e => setName(e.target.value)} placeholder="Ex : Aïcha Traoré" />
        </div>
        <div style={S.field}>
          <label style={S.label}>Code de la salle</label>
          <FocusInput
            value={code}
            onChange={e => setCode(e.target.value.toUpperCase())}
            placeholder="Ex : ABC123"
            style={{ letterSpacing:"4px", fontFamily:"monospace", fontSize:"1.1rem" }}
          />
        </div>

        <div style={S.btnRow}>
          <button style={S.btnSecondary} onClick={onClose}>Annuler</button>
          <button style={{ ...S.btnPrimary, opacity: loading||!name.trim()||code.length<4?.6:1 }} onClick={handleJoin} disabled={loading}>
            {loading ? "Connexion…" : "Rejoindre →"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Landing
// ─────────────────────────────────────────────────────────────
function Landing({ onAction }) {
  const [hov, setHov] = useState(null);
  return (
    <div style={S.page}>
      <div style={S.grid} />
      <div style={S.glow} />
      <div style={S.logo} className="fade-up">● ReunionPro</div>
      <h1 style={S.heroTitle} className="fade-up d1">Réunissez-vous.<br/>Sans frontières.</h1>
      <p style={S.heroSub} className="fade-up d2">
        Créez une salle en un clic, invitez vos partenaires via WhatsApp, et obtenez un compte-rendu automatique à la fin.
      </p>
      <div style={S.cardsRow} className="fade-up d3">
        {[
          { key:"create", icon:"🎬", label:"Nouvelle réunion", desc:"Créez une salle sécurisée Daily.co et invitez par WhatsApp.", strip:"linear-gradient(90deg,var(--accent),var(--accent2))" },
          { key:"join",   icon:"🔗", label:"Rejoindre",       desc:"Entrez le code reçu par WhatsApp pour rejoindre la salle.", strip:"linear-gradient(90deg,var(--accent2),var(--accent))" },
        ].map(c => (
          <div key={c.key} style={S.card(hov===c.key)}
            onMouseEnter={() => setHov(c.key)}
            onMouseLeave={() => setHov(null)}
            onClick={() => onAction(c.key)}
          >
            <div style={S.cardStrip(c.strip)} />
            <div style={S.cardIcon}>{c.icon}</div>
            <h3 style={S.cardH}>{c.label}</h3>
            <p style={S.cardP}>{c.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Écran de compte-rendu
// ─────────────────────────────────────────────────────────────
function Summary({ session, onRestart }) {
  const [progress,  setProgress]  = useState(0);
  const [transcript, setTranscript] = useState(null);
  const [summary,   setSummary]   = useState(null);
  const [loading,   setLoading]   = useState(true);
  const [step,      setStep]      = useState("Récupération de l'enregistrement…");

  useEffect(() => {
    const steps = [
      { p:20, msg:"Récupération de l'enregistrement Daily.co…" },
      { p:50, msg:"Transcription audio par Whisper…" },
      { p:80, msg:"Génération du compte-rendu par IA…" },
      { p:100, msg:"Finalisation…" },
    ];
    let i = 0;
    const t = setInterval(async () => {
      if (i < steps.length) {
        setProgress(steps[i].p);
        setStep(steps[i].msg);
        i++;
      } else {
        clearInterval(t);
        // Essayer de récupérer un vrai enregistrement
        try {
          const r = await fetch(`${API}/rooms/${session.roomName}/recordings`);
          const data = await r.json();
          if (data.data?.length) {
            setStep("Enregistrement trouvé !");
          }
        } catch {}
        // Fallback démo si pas de vraie transcription
        setTranscript([
          { speaker: session.name, text: "Réunion bien déroulée. Points discutés enregistrés." }
        ]);
        setSummary(`**Résumé — ${session.title || "Réunion"}**\n\nRéunion conduite par ${session.name}.\n\nLa réunion s'est tenue et les participants ont échangé sur les points de l'ordre du jour.\n\n**Actions à suivre :**\n— Rédiger le compte-rendu final\n— Envoyer aux participants`);
        setLoading(false);
      }
    }, 900);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{ ...S.page, justifyContent:"flex-start", paddingTop:"3rem" }}>
      <div style={S.glow} />
      <div style={S.summaryCard}>
        <h2 style={S.summaryH}>📋 Compte-rendu de réunion</h2>
        <div style={S.meta}>
          {session.title || "Sans titre"} · Animé par {session.name}
        </div>

        {loading ? (
          <>
            <div style={S.loadBar}><div style={S.loadFill(progress)} /></div>
            <p style={{ fontSize:".85rem", color:"var(--muted)" }}>{step}</p>
          </>
        ) : (
          <>
            {transcript && (
              <div style={S.transcriptBox}>
                {transcript.map((l, i) => (
                  <div key={i} style={{ marginBottom:".75rem" }}>
                    <span style={{ color:"var(--accent)", fontWeight:600, marginRight:".5rem" }}>{l.speaker} :</span>
                    {l.text}
                  </div>
                ))}
              </div>
            )}
            {summary && (
              <div style={S.summaryBox}>
                <strong style={{ color:"var(--accent2)", display:"block", marginBottom:".6rem" }}>📌 Résumé IA</strong>
                <pre style={{ fontFamily:"var(--font-b)", whiteSpace:"pre-wrap" }}>{summary}</pre>
              </div>
            )}
            <div style={{ display:"flex", gap:".75rem" }}>
              <button style={{ ...S.btnPrimary, flex:1 }} onClick={() => window.print()}>
                📄 Exporter PDF
              </button>
              <button style={{ ...S.btnSecondary, flex:1 }} onClick={onRestart}>
                🏠 Accueil
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// App Shell
// ─────────────────────────────────────────────────────────────
export default function App() {
  const [screen,  setScreen]  = useState("landing");
  const [modal,   setModal]   = useState(null);
  const [session, setSession] = useState(null);

  const handleStart = (data) => { setSession(data); setModal(null); setScreen("waiting"); };
  const handleEnter = () => setScreen("room");
  const handleLeave = () => setScreen("summary");
  const handleRestart = () => { setSession(null); setScreen("landing"); };

  return (
    <>
      {screen === "landing"  && <Landing onAction={setModal} />}
      {screen === "waiting"  && <WaitingRoom session={session} onEnter={handleEnter} />}
      {screen === "room"     && <Room session={session} onLeave={handleLeave} />}
      {screen === "summary"  && <Summary session={session} onRestart={handleRestart} />}

      {modal === "create" && <CreateModal onClose={() => setModal(null)} onStart={handleStart} />}
      {modal === "join"   && <JoinModal   onClose={() => setModal(null)} onStart={handleStart} />}
    </>
  );
}
